#ifndef FILEMAN_H
#define FILEMAN_H

#include "game.h"

void loadFromFile(const char* filename, Board* board);

#endif	/* FILEMAN_H */