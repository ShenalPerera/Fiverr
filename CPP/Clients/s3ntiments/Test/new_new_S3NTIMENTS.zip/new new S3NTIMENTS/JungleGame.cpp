#include <bits/stdc++.h>

using namespace std;


int main()
{
    std::cout << "Hello World!\n";
}

