#ifndef Lion

#include "Animal.h"
#include "Jumper.h"

class Lion : public Animal, public Jumper
{
	virtual char getLabel();
	virtual bool isMoveValid(Board* board, int x, int y);
	

	Lion(COLOR color, int X, int Y);
};

#endif
