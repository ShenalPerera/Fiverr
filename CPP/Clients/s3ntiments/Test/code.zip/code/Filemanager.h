#ifndef Filemanager
#define Filemanager
#include "Game.h"

void readBoard(const char* filename, Board* board);



#endif
