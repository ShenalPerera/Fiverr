#include <iostream>
#include "ChadaClocks.h"
#include "Menu.h"

using namespace std;

int main() {
    Menu menu;
    menu.getInput();

    return 0;
}
