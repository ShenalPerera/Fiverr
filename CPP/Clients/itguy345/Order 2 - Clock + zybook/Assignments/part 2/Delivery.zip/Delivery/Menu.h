//
// Created by shena on 21-Mar-22.
//

#ifndef PART_2_MENU_H
#define PART_2_MENU_H


class Menu {
    public:
        Menu();
        void displayMenu();
};


#endif //PART_2_MENU_H
