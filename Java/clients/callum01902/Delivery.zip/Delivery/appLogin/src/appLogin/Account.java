package appLogin;

public class Account {

	String user;
	String pass;
	
	public Account(String username, String password) {
		this.user = username;
		this.pass = password;
		
	}
	
	
}
